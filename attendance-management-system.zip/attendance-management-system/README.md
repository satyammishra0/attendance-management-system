attendance-management-system
============================
A Finger Print based Attendance Management System



