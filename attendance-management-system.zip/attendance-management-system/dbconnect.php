<?php
$conn = mysqli_connect("localhost", "root", "", "new_fpa");
