<?php
session_start();
include('dbconnect.php');
if (isset($_GET['action']) && $_GET['action'] = "show_course") {
   $id = $_SESSION['id'];
   $result = mysqli_query($conn, "select * from course_details where id_no='$id'");


   header('Content-type: text/xml');

   echo "<courses>";
   while ($row = mysqli_fetch_array($result)) {
      echo "<course>";
      echo "<course_name>" . $row['course_name'] . "</course_name>";
      echo "<course_id>" .  $row['course_id'] . "</course_id>";
      echo "</course>";
   }
   echo "</courses>";
   //header("Location: composerView.php");
}
